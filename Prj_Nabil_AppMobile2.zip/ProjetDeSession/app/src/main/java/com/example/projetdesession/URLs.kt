package com.example.projetdesession

object URLs {
    private val ROOT_URL = "http://192.168.1.35/androidphpmysql/registrationapi.php?apicall="
    val URL_REGISTER = ROOT_URL + "signup"
    val URL_LOGIN = ROOT_URL + "login"
}