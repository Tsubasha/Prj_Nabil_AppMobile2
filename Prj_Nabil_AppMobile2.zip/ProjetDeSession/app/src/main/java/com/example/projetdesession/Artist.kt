package com.example.projetdesession

class Artist (
    val name: String, val genre: String
    )