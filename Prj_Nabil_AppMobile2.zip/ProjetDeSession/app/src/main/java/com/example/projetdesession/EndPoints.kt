package com.example.projetdesession


object EndPoints {
    private val URL_ROOT = "http://127.0.0.1/WebApi/v1/?op="
    val URL_ADD_ARTIST = URL_ROOT + "addartist"
    val URL_GET_ARTIST = URL_ROOT + "getartists"
}