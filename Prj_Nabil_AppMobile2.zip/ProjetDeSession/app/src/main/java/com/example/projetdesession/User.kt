package com.example.projetdesession


class User(var id: Int, var name: String?, var email: String?, var gender: String?)