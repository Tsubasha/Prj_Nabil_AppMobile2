package com.example.projetdesession

import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import kotlinx.android.synthetic.main.activity_view_localisation.*

class ViewLocalisation : AppCompatActivity() {

    lateinit var currentlocation: Location

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var lm: LocationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var fromgps=lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        var fromwork=lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if(ContextCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_COARSE_LOCATION),1)
        }
        else {


            if (fromgps) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 0f, object : LocationListener {
                    override fun onLocationChanged(location: Location?) {
                        if (location!=null)
                        {
                            currentlocation=location
                        }

                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                    }

                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                    }

                    override fun onProviderEnabled(provider: String?) {
                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                    }

                    override fun onProviderDisabled(provider: String?) {
                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                    }
                })


            }
            var loc=lm.getLastKnownLocation((LocationManager.GPS_PROVIDER))
        }

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode)
        {
            1 ->{
                if(grantResults[0]== PackageManager.PERMISSION_GRANTED)
                {
                    Toast.makeText(this,"merci de votre confiance", Toast.LENGTH_LONG).show()
                }
                else
                {
                    Toast.makeText(this,"Bnadem ki Dayer", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
